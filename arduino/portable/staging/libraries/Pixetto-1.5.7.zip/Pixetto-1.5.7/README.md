Pixetto Library for Arduino
===========================

This library is to enable Pixetto vision sensor to do some computer vision tasks, and communicate with arduino through serial.

For more information about Pixetto, please visit at:

[VIA Pixetto](https://pixetto.ai/)

[Pixetto developer's guide (Chinese version)](https://learn.pixetto.ai/)
 